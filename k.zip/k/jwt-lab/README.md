# Node.js Practical Exam: JWT Login + Profile API

## 🎯 Objective
Build a simple JWT-based Login + Profile REST API using:
- **Node.js** & **Express.js** (Server framework)
- **MongoDB** & **Mongoose** (Database & ODM)
- **JWT (`jsonwebtoken`)** (Token generation and verification)
- **bcryptjs** (Secure password hashing)
- **dotenv** (Environment variable configuration)
- **Postman** (API testing and documentation)

---

## 📁 Project Folder Structure
```text
jwt-lab/
│-- models/
│   └── User.js          # Mongoose schema + pre-save bcrypt hashing hook
│-- middleware/
│   └── auth.js          # JWT verification & route protection middleware
│-- .env                 # Environment variables (PORT, MONGO_URI, JWT_SECRET)
│-- .env.example         # Template for environment configuration
│-- server.js            # Express server, MongoDB connection, & route endpoints
│-- package.json         # Project manifest and dependencies
│-- postman_collection.json # Ready-to-import Postman test collection
└── README.md            # Lab instructions and guide
```

---

## ⏱️ Two-Hour Exam Breakdown

### Hour 1 → Setup + Auth APIs
1. **Project Setup & Dependencies**
   - Initialize package: `npm init -y`
   - Install packages: `npm install express mongoose jsonwebtoken bcryptjs dotenv`
   - Install dev tools: `npm install -D nodemon`
2. **MongoDB Connection**
   - Configure connection via Mongoose inside `server.js` using `.env` values.
3. **User Model (`models/User.js`)**
   - Fields: `name`, `email` (unique, lowercase), `password`.
   - Automatic password hashing before saving using Mongoose `pre('save')` hook with `bcryptjs`.
   - Method `comparePassword` for checking login credentials.
4. **Register API (`POST /api/register`)**
   - Validates inputs (`name`, `email`, `password` ≥ 6 chars).
   - Checks if user already exists.
   - Saves hashed user to database and generates JWT token.
5. **Login API (`POST /api/login`)**
   - Validates email and password presence.
   - Verifies user existence and compares password hash with `bcrypt.compare`.
   - Generates and returns signed JWT token.

---

### Hour 2 → JWT + Middleware + Testing
1. **JWT Token Generation**
   - Signs payload `{ id: user._id, email: user.email }` with `process.env.JWT_SECRET` and expiration (`1h`).
2. **Auth Middleware (`middleware/auth.js`)**
   - Checks incoming HTTP `Authorization` header (`Bearer <token>`).
   - Verifies token validity and expiration.
   - Extracts user ID from decoded payload, retrieves user from database (excluding password with `-password`), and binds it to `req.user`.
3. **Protected Profile Route (`GET /api/profile`)**
   - Guarded by `auth` middleware.
   - Returns logged-in user's profile details (`name`, `email`, `createdAt`).
4. **Postman Testing**
   - Import `postman_collection.json`.
   - Test Register -> Login -> Access Profile with valid token -> Access Profile without token (401) -> Invalid token (401).
5. **Optional Logout Discussion**
   - Architectural discussion on stateless JWT vs. Stateful sessions.

---

## 🚀 Getting Started

### 1. Prerequisites
- [Node.js](https://nodejs.org/) installed (v16+ recommended).
- MongoDB running locally (`mongodb://localhost:27017/jwt_lab_db`) or a free [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) cluster connection string.

### 2. Installation
Open a terminal in the `jwt-lab` folder:
```bash
cd jwt-lab
npm install
```

### 3. Environment Variables
Verify or update `.env`:
```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/jwt_lab_db
JWT_SECRET=supersecret_jwt_exam_key_2026_!@#$%^
JWT_EXPIRES_IN=1h
```

### 4. Running the Server
- **Development mode** (auto-reload on save):
  ```bash
  npm run dev
  ```
- **Production start**:
  ```bash
  npm start
  ```
- Output should show:
  ```text
  🚀 Server running in development mode on port 5000
  📍 Test URL: http://localhost:5000
  ✅ MongoDB Connected successfully: localhost:27017/jwt_lab_db
  ```

---

## 📡 API Endpoints Reference

| Method | Endpoint | Access | Header | Description |
|---|---|---|---|---|
| `GET` | `/` | Public | None | API status and overview |
| `POST` | `/api/register` | Public | `Content-Type: application/json` | Register new user & return JWT |
| `POST` | `/api/login` | Public | `Content-Type: application/json` | Authenticate user & return JWT |
| `GET` | `/api/profile` | Protected | `Authorization: Bearer <token>` | Get profile of logged-in user |
| `POST` | `/api/logout` | Protected | `Authorization: Bearer <token>` | Logout & invalidation discussion |

*(Note: Routes are also aliased at root `/register`, `/login`, `/profile`, `/logout`)*

---

## 🧪 Request & Response Examples

### 1. Register User
- **URL**: `POST http://localhost:5000/api/register`
- **Request Body (JSON)**:
  ```json
  {
    "name": "Jane Doe",
    "email": "jane@example.com",
    "password": "mypassword123"
  }
  ```
- **Response (`201 Created`)**:
  ```json
  {
    "success": true,
    "message": "User registered successfully!",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "673f8a...",
      "name": "Jane Doe",
      "email": "jane@example.com",
      "createdAt": "2026-11-24T05:50:00.000Z"
    }
  }
  ```

---

### 2. Login User
- **URL**: `POST http://localhost:5000/api/login`
- **Request Body (JSON)**:
  ```json
  {
    "email": "jane@example.com",
    "password": "mypassword123"
  }
  ```
- **Response (`200 OK`)**:
  ```json
  {
    "success": true,
    "message": "Login successful!",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "673f8a...",
      "name": "Jane Doe",
      "email": "jane@example.com"
    }
  }
  ```

---

### 3. Get User Profile (Protected)
- **URL**: `GET http://localhost:5000/api/profile`
- **Headers**:
  ```http
  Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
  ```
- **Response (`200 OK`)**:
  ```json
  {
    "success": true,
    "message": "User profile retrieved successfully!",
    "user": {
      "_id": "673f8a...",
      "name": "Jane Doe",
      "email": "jane@example.com",
      "createdAt": "2026-11-24T05:50:00.000Z",
      "updatedAt": "2026-11-24T05:50:00.000Z",
      "__v": 0
    }
  }
  ```

---

### 4. Protected Route Failures
- **Case A: Missing Token**
  - **Headers**: None
  - **Status**: `401 Unauthorized`
  - **Response**:
    ```json
    {
      "success": false,
      "message": "Access denied. No token provided or invalid format. Please use \"Bearer <token>\"."
    }
    ```
- **Case B: Invalid / Expired Token**
  - **Headers**: `Authorization: Bearer invalid_token_123`
  - **Status**: `401 Unauthorized`
  - **Response**:
    ```json
    {
      "success": false,
      "message": "Invalid token. Authentication failed."
    }
    ```

---

## 📬 Postman Testing Guide

1. Open **Postman**.
2. Click **Import** (top left).
3. Drag & drop the file `jwt-lab/postman_collection.json`.
4. In the imported collection:
   - Run request **1. Health Check** to confirm the server is reachable.
   - Run request **2. Register User**. The test script automatically sets the `{{token}}` collection variable.
   - Run request **4. Get Profile (Success)**. Notice it immediately succeeds because it uses `{{token}}` under the **Authorization** tab (**Type: Bearer Token**).
   - Run requests **5** and **6** to verify error handling for unauthorized requests.

---

## 💡 Optional Topic: How Logout Works in JWT

A common exam question is: **"How do you implement Logout when using JWTs?"**

### 1. The Core Concept (Statelessness)
Traditional session-based authentication stores session records in server memory or a database (e.g., Redis). To log out, the server simply deletes the session from the store.

JWTs, however, are **stateless**:
- Once a JWT is signed by the server and issued to the client, it is mathematically valid until its expiration time (`exp`).
- The server does not store the token in a database by default.

### 2. Standard Approaches to Logout

#### Approach A: Client-Side Discard (Standard / Recommended for simple APIs)
- The client deletes the JWT from browser storage (`localStorage.removeItem('token')` or clearing the session cookie).
- The client cannot send the token anymore.
- **Trade-off**: If an attacker intercepted the token before deletion, it remains valid until expiration. Hence, keep token lifespans short (e.g., 15 minutes to 1 hour).

#### Approach B: Server-Side Blacklisting (Token Revocation List)
- When a user logs out, the client sends the token to `POST /api/logout`.
- The server stores the token string in a high-speed memory store (like **Redis**) with a TTL (Time-To-Live) equal to the remaining lifetime of the token.
- In the `auth` middleware, the server checks if the incoming token exists in Redis:
  ```javascript
  const isBlacklisted = await redisClient.get(token);
  if (isBlacklisted) return res.status(401).json({ message: 'Token has been revoked' });
  ```
- **Trade-off**: Requires database I/O for every request, reducing pure stateless performance.

#### Approach C: Refresh Token Rotation
- Issue two tokens:
  1. **Short-lived Access Token** (e.g., 10 minutes) kept in memory.
  2. **Long-lived Refresh Token** (e.g., 7 days) stored securely in `httpOnly` cookie and tracked in the database.
- On logout: The server deletes the refresh token record from the database. When the access token expires in minutes, the user can no longer refresh it and must log in again.

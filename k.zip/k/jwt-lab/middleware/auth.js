const jwt = require('jsonwebtoken');
const User = require('../models/User');

/**
 * Authentication Middleware
 * 1. Checks for Authorization header (Bearer format)
 * 2. Verifies JWT signature and expiry using JWT_SECRET
 * 3. Fetches user from DB (excluding password)
 * 4. Attaches user to req.user for downstream handlers
 */
const auth = async (req, res, next) => {
  try {
    // 1. Get header value
    const authHeader = req.header('Authorization');

    // 2. Check if Authorization header exists and has 'Bearer ' prefix
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Access denied. No token provided or invalid format. Please use "Bearer <token>".',
      });
    }

    // 3. Extract the raw token string
    const token = authHeader.substring(7).trim(); // Remove 'Bearer ' (7 characters)

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access denied. Token is missing.',
      });
    }

    // 4. Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // 5. Find the user in database using payload ID (exclude password field)
    const user = await User.findById(decoded.id).select('-password');
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication failed. User account does not exist or has been deleted.',
      });
    }

    // 6. Attach user to request object
    req.user = user;
    req.token = token;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token. Authentication failed.',
      });
    }

    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token has expired. Please log in again to obtain a new token.',
      });
    }

    return res.status(500).json({
      success: false,
      message: 'Server error during token verification.',
      error: error.message,
    });
  }
};

module.exports = auth;

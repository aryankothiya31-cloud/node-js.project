// Load environment variables from .env file
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');

const User = require('./models/User');
const auth = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 5000;

// ==========================================
// 1. Core Middlewares
// ==========================================
// Parse JSON request bodies
app.use(express.json());

// ==========================================
// 2. Database Connection
// ==========================================
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`✅ MongoDB Connected successfully: ${conn.connection.host}/${conn.connection.name}`);
  } catch (error) {
    console.error(`❌ MongoDB connection error: ${error.message}`);
    // Optional: Keep server running or exit
    // process.exit(1);
  }
};

connectDB();

// ==========================================
// 3. Helper Functions
// ==========================================
/**
 * Generate a JSON Web Token
 * @param {string} userId - User's MongoDB ObjectId
 * @param {string} email - User's email
 * @returns {string} - Signed JWT
 */
const generateToken = (userId, email) => {
  return jwt.sign(
    { id: userId, email: email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '1h' }
  );
};

// ==========================================
// 4. API Routes
// ==========================================

/**
 * @route   GET /
 * @desc    API Health Check & Documentation
 * @access  Public
 */
app.get('/', (req, res) => {
  res.json({
    message: 'Welcome to JWT Auth & Profile REST API',
    endpoints: {
      register: 'POST /api/register (or /register)',
      login: 'POST /api/login (or /login)',
      profile: 'GET /api/profile (or /profile) [Protected: Bearer <token>]',
      logout: 'POST /api/logout (or /logout) [Protected: Bearer <token>]',
    },
    status: 'Server is running',
  });
});

/**
 * Controller: Register User
 */
const registerUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // 1. Basic validation
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: name, email, password.',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.',
      });
    }

    // 2. Check if user already exists
    const existingUser = await User.findOne({ email: email.toLowerCase().trim() });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'A user with this email address already exists. Please login instead.',
      });
    }

    // 3. Create user (password is automatically hashed via User schema pre-save hook)
    const user = new User({
      name,
      email,
      password,
    });

    await user.save();

    // 4. Generate JWT token
    const token = generateToken(user._id, user.email);

    // 5. Respond with user info and token
    return res.status(201).json({
      success: true,
      message: 'User registered successfully!',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    console.error('Register error:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error during user registration.',
      error: error.message,
    });
  }
};

/**
 * Controller: Login User
 */
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // 1. Basic validation
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.',
      });
    }

    // 2. Find user by email
    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    // 3. Compare entered password with hashed password in database
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    // 4. Generate JWT token
    const token = generateToken(user._id, user.email);

    // 5. Return token and user details
    return res.status(200).json({
      success: true,
      message: 'Login successful!',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error during login.',
      error: error.message,
    });
  }
};

/**
 * Controller: Get Logged-in User Profile (Protected)
 */
const getProfile = async (req, res) => {
  // req.user is set by the auth middleware (excluding password)
  res.status(200).json({
    success: true,
    message: 'User profile retrieved successfully!',
    user: req.user,
  });
};

/**
 * Controller: Logout Discussion Endpoint (Protected)
 */
const logoutUser = async (req, res) => {
  // JWT is stateless: token invalidation is primarily managed client-side
  res.status(200).json({
    success: true,
    message: 'Logged out successfully! (Client should delete the stored JWT from local storage/cookies)',
    discussion: {
      mechanism: 'Stateless JWT',
      clientAction: 'Remove token from client storage (localStorage, sessionStorage, or client cookie).',
      serverAlternatives: [
        'Blacklisting/Revocation: Store invalidated tokens in Redis with TTL matching token expiry.',
        'Token Rotation: Use short-lived access tokens and revocable refresh tokens stored in database.',
        'User Token Versioning: Increment a tokenVersion on the User model to invalidate all existing tokens.',
      ],
    },
  });
};

// Route registrations (support both /api/* and root level /* for convenience in lab evaluations)
app.post('/api/register', registerUser);
app.post('/register', registerUser);

app.post('/api/login', loginUser);
app.post('/login', loginUser);

app.get('/api/profile', auth, getProfile);
app.get('/profile', auth, getProfile);

app.post('/api/logout', auth, logoutUser);
app.post('/logout', auth, logoutUser);

// ==========================================
// 5. 404 Route Handler
// ==========================================
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Cannot ${req.method} ${req.originalUrl}. Route not found.`,
  });
});

// ==========================================
// 6. Global Error Handler
// ==========================================
app.use((err, req, res, next) => {
  console.error('Unhandled Error:', err.stack);
  res.status(500).json({
    success: false,
    message: 'An unexpected internal server error occurred.',
    error: process.env.NODE_ENV === 'production' ? null : err.message,
  });
});

// ==========================================
// 7. Start Server
// ==========================================
app.listen(PORT, () => {
  console.log(`🚀 Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
  console.log(`📍 Test URL: http://localhost:${PORT}`);
});
